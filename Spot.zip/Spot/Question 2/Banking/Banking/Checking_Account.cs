﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Banking
{
    class Checking_Account : Account
    {        

        public Checking_Account(decimal balance,string account_balance)
        {
        }
    }
}
