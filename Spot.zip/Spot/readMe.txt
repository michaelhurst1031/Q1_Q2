Question 1

Create the Database from the sql file and run.

exec dbo.GET_ReportsToInfo

Question 2 

Run the sln file in Banking/

Program.cs Toggles between Checking and Saving Account.

All the initial values are hard coded versus database / site driven.
//Savings Account Check
Savings_Account acct = new Savings_Account(startingBalance, AccountType);

// For Checking Account
//Checking_Account acct = new Checking_Account(startingBalance);